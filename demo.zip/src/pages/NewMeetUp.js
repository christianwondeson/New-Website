import NewMeetForm from '../components/meetups/NewMeetForm';

function NewMeetUpPage()
{
    function addMeetupHandle(meetupData)
    {
        fetch('https://react-firsebaseend-default-rtdb.firebaseio.com/meetups.json', 
        {
            method:'POST',
            body: JSON.stringify(meetupData),
            headers:{'Content-Type': 'appliction/json'
        }
        });
    }


    return <div>
        <h1>Add New Meetup</h1>
        <NewMeetForm onaddMeet={addMeetupHandle}/>
    </div>
}
export default NewMeetUpPage;