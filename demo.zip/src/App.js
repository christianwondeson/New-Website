import { Route , Routes } from 'react-router-dom';

import NewMeetUpPage from './pages/NewMeetUp';
import AllMeetUpsPage from './pages/AllMeetUps';
import FavoritePage from './pages/Favorite';
import LayOut from './components/layout/LayOut';

function App() {

   //localhost:3000

  return (
    <LayOut>
      <Routes>
        <Route path='/' element = {<AllMeetUpsPage />} />
        <Route path ='/newmeet' element ={<NewMeetUpPage/>} />
        <Route path="/favorite" element = {<FavoritePage/>} />
      </Routes>
    </LayOut>
  );
}

export default App;
