import CardSty from "./Card.module.css";

function Card(props) {
  return <div className={CardSty.card}>{props.children}</div>;
  {
    /*this component is a wrap for card sructured element of the page*/
  }
}
export default Card;
{/*custom component  it pass the component of our wrapped value*/}