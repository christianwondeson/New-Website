import { Link } from 'react-router-dom';

import stylingNav from './MainNav.module.css';

function MainNav()
{
    return (
        <header className = {stylingNav.header}>
        <div className = {stylingNav.title}>react<span className={stylingNav.titleSpan}>meetups</span> </div>
        <nav>
            <ul className={stylingNav.navBar}>
    {/*prevent sending unnecessary server request */}
                <li>
                   <Link to = '/' className={stylingNav.links}>all meetups</Link>
                </li>
                <li>
                    <Link to = '/newmeet' className={stylingNav.links}>newmeet ups</Link>
                </li>
                <li>
                    <Link to = '/favorite' className={stylingNav.links}>favorite</Link>
                </li>
            </ul>
        </nav>
    </header>
    );
}

export default MainNav;