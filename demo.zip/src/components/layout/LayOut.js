import MainNav from './MainNav';
import layoutSty from './LayOut.module.css';

function LayOut(props)
{
return (
    <div>
         <MainNav/>
         <main>
            {props.children}
         </main>
    </div>
);
}
export default LayOut;