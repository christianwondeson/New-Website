import { useRef } from 'react';

import FormSty from './NewMeetForm.module.css';
import Card from '../UI/Card';

function NewMeetForm(props)
{

    const titleRef = useRef();
    const imageRef = useRef();
    const addressRef = useRef();
    const descRef = useRef();

    function submitHandler(event)
    {
        event.preventDefault();

        {/*prevent default default request our local host to handle the submition*/}

        const enteredtitle = titleRef.current.value;
        const enteredurl = imageRef.current.value;
        const enteredaddress = addressRef.current.value;
        const enteredDesc = descRef.current.value;

        const meetupData=
        {
            title:enteredtitle,
            image:enteredurl,
            address:enteredaddress,
            description:enteredDesc
        }

        props.onaddMeet(meetupData);
    }

    return (
        <Card>
            <form className={FormSty.form} onSubmit={submitHandler}>
                <div className={FormSty.control}>
                    <label htmlFor="title"> Meetup Title</label>
                    <input type="text" required id="title" ref={titleRef}/>
                </div>
                <div className={FormSty.control}>
                    <label htmlFor="image"> Meetup Image</label>
                    <input type="url" required id="image" ref={imageRef}/>
                </div>
                <div className={FormSty.control}>
                    <label htmlFor="address"> Meetup Address</label>
                    <input type="text" required id="address" ref={addressRef}/>
                </div>
                <div className={FormSty.control}>
                    <label htmlFor="description"> Description</label>
                    <textarea id="description" rows='5' className={FormSty.txtarea} ref={descRef}></textarea>
                <div className={FormSty.actions}> 
                    <button>Add Meetups</button>
                </div>    
                </div>
            </form>
        </Card>
    )
}

export default NewMeetForm;